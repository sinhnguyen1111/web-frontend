var text = document.getElementById('myText');
	console.log(text);
	text.style.color="green";
text.innerHTML="Hello World!!";
var content1 = text.innerHTML;
	console.log(content1);

var selector = document.getElementsByClassName('hello');
	console.log(selector);
//Thay dổi và lấy giá trị thuộc tính của HTML
var link = document.getElementById('link-fb');//Lấy ra đối tượng
 console.log(link);//In ra màn hìn đối tượng đã đk lấy
var link1 = link.href;//Lấy giá trị thuộc tính
	console.log(link1);//Kieetm tra xem đã lấy được giá trị cuat thuộc tính chưa.

//lấy thẻ theo class và in ra màn hình console.
//css cho phần tử thứ 0 trong mảng.
var input1= document.getElementsByClassName('website');
	console.log(input1[0]);
 	input1[0].style.border="2px solid blue";
 
 //lấy tên thẻ theo tên thẻ
 var about=document.getElementsByTagName('h3');
 	 console.log(about);
 	about.innerHTML = "Tôi là ai..";
 var content=about.innerHTML;//Lấy ra nội dung bên trong thẻ 
console.log(content);

var content3 = document.getElementById('message');
console.log(content3);
//Thiết lập Css
	content3.style.color="red";
// Lấy giá trị của css ra màn hình console.
var value= content3.style.color;
console.log(value);

function buttonClick()
{
	document.getElementById('message').innerHTML="Zent Group";
}

function buttonOver(element) {
	element.style.color="pink";
}
function buttonOut()
{
	document.getElementById('myText').style.color="red";
}
function loadPage(element)
{
	alert('Ban dang tai trang');
}
//khi click ra ngoai truong nhap se xuat hien
function buttonOnblur(element)
{
	element.style.background="yellow";
}
//Khi click vao truong nhap se xuat hien
function buttonFocus(element)
{
	element.style.background="blue";
}
//Onchange xảy ra khi giá trị của 1 phần tử đã dược thay đổi
//
function buttonChange(element)
{
	var val= element.value;
	alert(val);
}
function submitTest(element)
{
	alert('đang gửi');
	// element.style.background="green";
}