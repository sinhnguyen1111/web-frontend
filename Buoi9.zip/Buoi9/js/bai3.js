	// var button=document.getElementsByClassName('default');
	// console.log(button);
	// var text=document.getElementsByClassName('text');
	// console.log(text);

// function buttonDefault(element)
// {
// 	var text=document.getElementsByClassName('text');


// }	
var text=document.getElementById('btn');	
var min=8;
var max=100;
function buttonFont(size)
{
	if(size==16)
	document.getElementsByClassName('text').style.fontSize=size;
	
}
function buttonPig(size)
{
	size++;
	document.getElementsByClassName('text').style.fontSize=size;
}