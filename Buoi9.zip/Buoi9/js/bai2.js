
// var button=document.getElementById('btn1');

function checkAll()
{
	//lấy danh sách chechbox
	var check= document.getElementsByName('name');
	for(var i=0;i<check.length;i++)
	{
		check[i].checked=true;
	}
}

function uncheckAll()
{
	var check= document.getElementsByName('name');//Trả về giá trị của thuộc tính name
	for(var i=0;i<check.length;i++)
	{
		check[i].checked=false;
	}
}
function mouseOverTest(element)
{
	element.style.background="green";
}
function mouseOutTest(element)
{
	element.style.background="#2ECCFA";
}