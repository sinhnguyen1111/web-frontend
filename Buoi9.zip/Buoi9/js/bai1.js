var button=document.getElementsByClassName('tab');
var content = document.getElementsByClassName('content');

function eve(element)
{
	for(var i=0; i<content.length; i++)
	{
		content[i].style.display="none";
	}
	var item=element.id;
	var text= document.getElementsByClassName(item);
	// console.log(text);
	text[0].style.display="block";
	element.style.background="gray";
	element.style.color="white";
}