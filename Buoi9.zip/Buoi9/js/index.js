var element= document.getElementById('myText');
	console.log(element);
 element.innerHTML="Ahihi!! Đồ ngốc";
var contentHTML = element.innnerHTML;

var element1 = document.getElementsByClassName('content');
	console.log(element1);
var element2 = document.getElementsByTagName('h1');
	console.log(element2);	
var element3 = document.getElementById('link-fb');
	element3.href = 'https://google.com';
	console.log(element3.href);
element3.style.color='red';
function buttonClick(){
	element3.style.color='blue';
	var btn=document.getElementById('bt');
	btn.style.color='blue';
}
 var button1=document.getElementById('bt');
 	button1.addEventListener('click',buttonClick,false);

function changeColorOver(element)
{
	element.style.color ="red";
}
function changeColorOut(element)
{
	element.style.color ="green";
}
function loadPage(element)
{
	alert('Trang web da duoc tai');
}
function onBlurtest(element)
{
	var val = element.value;
	var val = val.toUpperCase();
	element.value = val;
}
 function onFocusTest(element)
 {
 	element.style.color="red";
 }

 function onChangeTest(element)
 {
 	var val = element.value;
 	alert(val);
 }
 var element_a = document.getElementById('link-fb');
 console.log(element_a.parentNode);
 
 var element_body = document.getElementsByTagName('body')[0];
 console.log(element_body.children[0]);
